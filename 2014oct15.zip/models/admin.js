'use strict';


module.exports = function AdminModel() {
    return {
        name: 'admin'
    };
};
