'use strict';


module.exports = function ServiceModel() {
    return {
        name: 'service'
    };
};
