'use strict';


module.exports = function OrderModel() {
    return {
        name: 'order'
    };
};
