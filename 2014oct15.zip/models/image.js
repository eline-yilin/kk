'use strict';


module.exports = function ImageModel() {
    return {
        name: 'image'
    };
};
