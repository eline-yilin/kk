<?php
/* $config = array (
		"DB_DSN"  => 'mysql:dbname=test;host=localhost',//'cmsfdb101.dev.wl.mezimedia.com',
		"DB_USER"  => 'root',
		"DB_PWD"  => 'goumao',
		); */
 $config = array (
		"DB_DSN"  => 'mysql:dbname=shengzhu;host=121.199.55.129',//'cmsfdb101.dev.wl.mezimedia.com',
		"DB_USER"  => 'admin',
		"DB_PWD"  => 'yuShu1234',
); 
?>